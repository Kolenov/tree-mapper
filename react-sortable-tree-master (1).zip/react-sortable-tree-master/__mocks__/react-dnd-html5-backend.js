/* eslint-disable import/no-extraneous-dependencies */
import TestBackend from 'react-dnd-test-backend';

module.exports = TestBackend;
