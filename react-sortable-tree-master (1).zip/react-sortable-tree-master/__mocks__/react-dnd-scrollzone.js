module.exports = el => el;
module.exports.createVerticalStrength = () => {};
module.exports.createHorizontalStrength = () => {};
